Outils utilisés : HTML, CSS, JS, fetch-jsonp et bootstrap.

Pour lancer le projet :

    1) Installer fetch-jsonp dans le dossier src avec la commande : npm install fetch-jsonp
    2) Lancer le serveur local avec la commande : live-server (commande à effectuer dans le dossier src)